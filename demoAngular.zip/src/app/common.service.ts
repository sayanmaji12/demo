import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor() {
  }
  
  getUserId(): any {
    var userData = localStorage.getItem("demologin");
    if(userData!==undefined && userData!==null && userData!=""){
      let response = JSON.parse(userData);
      return response.user_id;
    }else{
      return null;
    }
  }
  userLogId(): any {
    var userData = localStorage.getItem("demologin");
    if(userData!==undefined && userData!==null && userData!=""){
      let response = JSON.parse(userData);
      return response.userLogId;
    }else{
      return null;
    }
  }
  getToken(): any {
    var token = localStorage.getItem("token");
    if(token!==undefined && token!==null && token!=""){
      let response = JSON.parse(token);
      return response;
    }else{
      return null;
    }
  }
  validateEmail(inputText: string): any {
    const mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (inputText.match(mailformat)) {
      // alert('Valid email address!');
      return true;
    } else {
      return false;
    }
  }
  validatePhone(inputText: string) {
    /* var a = document.getElementById(txtPhone).value;*/
     var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
     if (filter.test(inputText)) {
         return true;
     }
     else {
         return false;
     }
 }
  isEmail(email: string) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if(!regex.test(email)) {
      return false;
    }else{
      return true;
    }
  }
  IsName(Name: string) {
    var regex = /^([a-zA-Z ]{3,16})$/;
    if(!regex.test(Name)) {
      return false;
    }else{
      return true;
    }
  }

  PassWord(Pass: string){
    //var regex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{5,12}$/;
    var regex =	/^([a-zA-Z0-9!@#$%^&*]{5,12})+$/;
    if(!regex.test(Pass)) {
      return false;
    }else{
      return true;
    }
  }
  NumBer(Num: string){
    //var regex = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{5,12}$/;
    var regex =	/^[0-9-+]+$/;
    if(!regex.test(Num)) {
      return false;
    }else{
      return true;
    }
  }

  groupBy(xs: any, key: string): any {
    return xs.reduce((rv: any, x: any) => {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  }
}
