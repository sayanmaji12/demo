import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../rest-api.service';
@Component({
  selector: 'app-forget-pass',
  templateUrl: './forget-pass.component.html',
  styleUrls: ['./forget-pass.component.css']
})
export class ForgetPassComponent implements OnInit {
  email="" as any
  password = "" as any 
  conpassword= "" as any
  constructor(public router:Router,public rest:RestApiService) { }

  ngOnInit(): void {
  }
  forgetPass():any{
    if(this.email==""){
      alert("Please enter email");
      return false;
    }
    if(this.password==""){
      alert("Please enter email");
      return false;
    }
    if(this.password!=this.conpassword){
      alert("Passwords did not match");
      return false;
    }
    var data = {
      email:this.email,
      password:this.password
    }
    this.rest.forgetpass(data).subscribe((res: any) => {
      if(res.success){
        alert(res.message)
          this.router.navigate(['']);
        
        console.log(res)
      }else{
        alert(res.message)
      }
    })
  }
}
