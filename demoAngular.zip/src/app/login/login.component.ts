import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../rest-api.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email = '' as any;
  password = '' as any;
  constructor(public router:Router,public rest:RestApiService) { }
  
  ngOnInit(): void {

  }
  login():any{
    if(this.email==""){
      alert("Please enter email");
      return false;
    }
    if(this.password==""){
      alert("Please enter email");
      return false;
    }
    var data = {
      email:this.email,
      password:this.password
    }
    this.rest.login(data).subscribe((res: any) => {
      if(res.success){
        localStorage.setItem("demologin",JSON.stringify(res.response));
        localStorage.setItem("token",JSON.stringify(res.token));
        if(res.response.type==1){
          this.router.navigate(['/admin']);
        }else{
          this.router.navigate(['/user']);
        }
        console.log(res)
      }else{
        alert(res.message)
      }
    })
  }
}
