import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../../rest-api.service';
import { Subscription } from 'rxjs'; 
import { CommonService } from '../../common.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  images = [] as any 
  constructor(public router:Router,public rest:RestApiService,public common:CommonService) { }

  ngOnInit(): void {
    if(this.common.getToken()==null){
      this.router.navigate(['']);
    }
    this.getImage()
  }
  logout():any{
   
    var data = {
      userLogId:this.common.userLogId()
    }
    this.rest.logout(data).subscribe((res: any) => {
      if(res.success){
        localStorage.removeItem('demologin');
        localStorage.removeItem('token');
        this.router.navigate(['']);
      }
    })
  }
  getImage():any{
   
    var data = {
    }
    this.rest.getImage(data).subscribe((res: any) => {
      if(res.success){
       this.images = res.response
      }
    })
  }
}
