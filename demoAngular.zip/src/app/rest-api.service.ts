import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { CommonService } from './common.service';
const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class RestApiService {
  API_ROOT = "http://localhost:6065";
  image_path = "http://localhost:6065/";
  
  constructor(private http:HttpClient,public common:CommonService) { }
  
  login(data: any) {
    return this.http.post(this.API_ROOT + '/login', JSON.stringify(data), httpOptions);
  }
  forgetpass(data: any) {
    return this.http.post(this.API_ROOT + '/forgetpass/password', JSON.stringify(data), httpOptions);
  }
  logout(data: any) {
    var reqHeader = ({
      headers: new HttpHeaders({'Content-Type': 'application/json','Authorization': 'Bearer ' +this.common.getToken()})
    })
    return this.http.post(this.API_ROOT + '/logout', JSON.stringify(data), reqHeader);
  }
  register(data: any) {
    return this.http.post(this.API_ROOT + '/register', JSON.stringify(data), httpOptions);
  }
  fileupload(data: any) {
    var reqHeader = ({
      headers: new HttpHeaders({'Authorization': 'Bearer ' +this.common.getToken() })
    })
    return this.http.post(this.API_ROOT + '/fileupload',data,reqHeader);
  }
  addimage(data: any) {
    var reqHeader = ({
      headers: new HttpHeaders({'Content-Type': 'application/json','Authorization': 'Bearer ' +this.common.getToken()})
    })
    return this.http.post(this.API_ROOT + '/addimage',data,reqHeader);
  }
  getImage(data: any) {
    var reqHeader = ({
      headers: new HttpHeaders({'Content-Type': 'application/json','Authorization': 'Bearer ' +this.common.getToken()})
    })
    return this.http.post(this.API_ROOT + '/getImage',data,reqHeader);
  }
  
}
