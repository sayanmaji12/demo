import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestApiService } from '../../rest-api.service';
import { Subscription } from 'rxjs'; 
import { CommonService } from '../../common.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  image_url = "" as any;
  fileUploadSub?: Subscription;
  constructor(public router:Router,public rest:RestApiService,public common:CommonService) { }

  ngOnInit(): void {
    console.log()
    if(this.common.getToken()==null){
      this.router.navigate(['']);
    }
  }
  logout():any{
   
    var data = {
      userLogId:this.common.userLogId()
    }
    this.rest.logout(data).subscribe((res: any) => {
      if(res.success){
        localStorage.removeItem('demologin');
        localStorage.removeItem('token');
        this.router.navigate(['']);
      }
    })
  }

  uploadExisting(): void {
    const fileUp = document.getElementById('fileUp');
    if (fileUp) {
      this.uploadFile = this.uploadFile.bind(this);
      fileUp.addEventListener('change', this.uploadFile);
      fileUp.click();
    }
  }
  uploadFile(event: any): any {
    const files = event.target.files;
    const fd = new FormData();
    fd.append('image', files[0]);
    // fd.append('companyId', this.common.getCompanyId());
    this.fileUploadSub = this.rest.fileupload(fd).subscribe((res: any) => {
      if (this.fileUploadSub) {
        this.fileUploadSub.unsubscribe();
      }
      const fileUp = document.getElementById('fileUp');
      if (fileUp) {
        fileUp.removeEventListener('change', this.uploadFile);
        // this.isUpload = false;
      }
      console.log(res)
      if (res.success) {
          alert('File uploaded successfully');
        this.image_url = res.response.fileName;
       
      } else { 
        alert('Something went wrong')
      }
    }, (err: any) => {
      
    });
  }
  addimage(){
    var data = {
      image_url:this.image_url
    }
    this.rest.addimage(data).subscribe((res: any) => {
      if (res.success) {
        alert(res.message);
      } else { 
          alert('Something went wrong')
        }
    })
  }
}
