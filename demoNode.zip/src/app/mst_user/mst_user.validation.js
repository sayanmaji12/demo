const util = require('../../utility/util');

module.exports.login = (data) => {
    let errcounter = 0;
    if (data.email === undefined || data.email == null) {
        util.createLog("email is missing");
        errcounter++;
    }
    if (data.password === undefined || data.password == null) {
        util.createLog("password is missing");
        errcounter++;
    }
    return errcounter <= 0;
}
module.exports.logout = (data) => {
    let errcounter = 0;
    if (data.userLogId === undefined || data.userLogId == null) {
        util.createLog("userLogId is missing");
        errcounter++;
    }
    return errcounter <= 0;
}
module.exports.addUser = (data) => {
    let errcounter = 0;
    if (data.name === undefined || data.name == null) {
        util.createLog("name is missing");
        errcounter++;
    }
    if (data.email === undefined || data.email == null) {
        util.createLog("email is missing");
        errcounter++;
    }
    if (data.password === undefined || data.password == null) {
        util.createLog("password is missing");
        errcounter++;
    }
    return errcounter <= 0;
}
module.exports.addimage = (data) => {
    let errcounter = 0;
    if (data.image_url === undefined || data.image_url == null) {
        util.createLog("image_url is missing");
        errcounter++;
    }
    return errcounter <= 0;
}
module.exports.getImage = (data) => {
    let errcounter = 0;
   
    return errcounter <= 0;
}
module.exports.forgetPassReq = (data) => {
    let errcounter = 0;
    if (data.email === undefined || data.email == null) {
        util.createLog("email is missing");
        errcounter++;
    }
    if (data.password === undefined || data.password == null) {
        util.createLog("password is missing");
        errcounter++;
    }
    return errcounter <= 0;
}

