const express       = require('express');
const router        = express.Router();
const validator     = require('../../utility/validator');
const model         = require('./mst_user.model');
const validate      = require('./mst_user.validation');
const util          = require('../../utility/util');
const common = require('../services/common.service');
const token  = require('../../utility/token')

const formdataservice = require('../services/formdata.service');
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to login
*/
router.post('/login', async (req, res) => {   
    let reqData = validator.requestFilter(req.body);
    if (validate.login(reqData)) {
        const resp = await model.login(req.body);
        if(resp.response){
            var generatedToken = await token.GetWebToken(resp.response.user_id);
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response,token:generatedToken});
        }else{
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }
        
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
    
});
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to logout
*/
router.post('/logout', async (req, res) => {   
    let reqData = validator.requestFilter(req.body);
    if (validate.logout(reqData)) {
        const resp = await model.logout(req.body);
        if(resp.response){
            
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }else{
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }
        
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
    
});

/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to create user
*/
router.post('/register', async (req, res) => {   
    let reqData = validator.requestFilter(req.body);
    if (validate.addUser(reqData)) {
        const resp = await model.register(req.body);
        if(resp.response){
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }else{
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }
        
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
    
});
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to upload image
*/
router.post('/fileupload', async (req, res) => {
    const reqbody = await formdataservice.handelFormData(req, 'file');
    res.json({success: true, status: 200, message: '', response: reqbody});
});

/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to add image name into database
*/
router.post('/addimage', async (req, res) => {   
    let reqData = validator.requestFilter(req.body);
    if (validate.addimage(reqData)) {
        const resp = await model.addimage(req.body);
        if(resp.response){
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }else{
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }
        
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
    
});
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to add image name into database
*/
router.post('/getImage', async (req, res) => {   
    let reqData = validator.requestFilter(req.body);
    if (validate.getImage(reqData)) {
        const resp = await model.getImage(req.body);
        if(resp.response){
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }else{
            res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
        }
        
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
    
});
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to forget password
*/
router.post('/forgetpass/password', async (req, res) => {
   
    let reqData = validator.requestFilter(req.body);
    if (validate.forgetPassReq(reqData)) {
        const resp = await model.forgetPassReq(req.body);
        res.json({success: resp.success, status: resp.status, message: resp.message, response: resp.response});
    } else {
        res.json({success: false, status: util.statusCode.PARAM_MISSING, message: "Parameter missing", response: null});
    }
        
});
module.exports = router;