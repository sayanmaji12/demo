const dao = require('./mst_user.dao');
const token = require('../../utility/token');
const util = require('../../utility/util');
/*
    Sayan Maji
    Date: 23.02.2023
    This method will use to login
*/
module.exports.login = async (data) => {
    try {
        let resp = await dao.login(data)
        if (resp) {
            const isMatch = await util.comparePass(data.password, resp.password);
            if (isMatch) {
                var user_audit_logs = await dao.add_user_audit_logs(resp)
                delete resp['password'];
                // console.log(resp)

                resp['userLogId'] = user_audit_logs;
                return { success: true, status: util.statusCode.SUCCESS, message: '', response: await util.encryptResponse(resp) }


            } else {
                return { success: false, status: util.statusCode.INTERNAL, message: 'Password is incorrect', response: null }
            }


        } else {
            return { success: false, status: util.statusCode.INTERNAL, message: 'Your username or password is incorrect', response: null }
        }
    } catch (e) {
        console.log(e)
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}
module.exports.logout = async (data) => {
    try {
        let resp = await dao.logout(data)
        if (resp) {
            return { success: true, status: util.statusCode.SUCCESS, message: 'Logout successfully', response: await util.encryptResponse(resp) }
        } else {
            return { success: false, status: util.statusCode.INTERNAL, message: 'Internal server error', response: null }
        }
    } catch (e) {
        console.log(e)
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}
module.exports.register = async (data) => {
    try {
        let isExists = await dao.check(data);
        if (!isExists) {
            // data.passkey =  data.password;
            data.password = await util.generateHash(data.password);
            const resp = await dao.add(data);
            if (resp) {
                return { success: true, status: util.statusCode.SUCCESS, message: 'User added successfully', response: null }
            } else {
                return { success: false, status: util.statusCode.INTERNAL, message: 'Internal server error', response: null }
            }
        } else {
            return { success: false, status: util.statusCode.NAME_EXISTS, message: 'User name already exists', response: null }
        }


    } catch (e) {
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}
module.exports.addimage = async (data) => {
    try {

        const resp = await dao.addimage(data);
        if (resp) {
            return { success: true, status: util.statusCode.SUCCESS, message: 'Image added successfully', response: null }
        } else {
            return { success: false, status: util.statusCode.INTERNAL, message: 'Internal server error', response: null }
        }



    } catch (e) {
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}
module.exports.getImage = async (data) => {
    try {

        const resp = await dao.getImage(data);
        if (resp) {
            return { success: true, status: util.statusCode.SUCCESS, message: '', response: resp }
        } else {
            return { success: false, status: util.statusCode.INTERNAL, message: 'Internal server error', response: null }
        }



    } catch (e) {
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}
module.exports.forgetPassReq = async (data) => {
    try {
        let resp = await dao.check(data)
        if (resp) {
            data.password = await util.generateHash(data.password);
            const resp = await dao.updatePassword(data);
            return { success: true, status: util.statusCode.SUCCESS, message: 'Password changed successfully', response: await util.encryptResponse(resp) }


        } else {
            return { success: false, status: util.statusCode.INTERNAL, message: 'User not found', response: null }
        }
    } catch (e) {
        return { success: false, status: util.statusCode.SOME_ERROR_OCCURRED, message: 'Some error occurred', response: null }
    }
}