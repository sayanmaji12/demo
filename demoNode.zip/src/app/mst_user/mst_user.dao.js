const readConn = require('../../dbconnection').readPool;
const writeConn = require('../../dbconnection').writePool;
const common = require('../services/common.service');
const util = require('../../utility/util');
const axios = require("axios");
const config = require('../../config');

module.exports.login = async (data) => {
    try {
        const sql = "SELECT id as user_id,name,email,type,password FROM `user_details` where email = ?";
        console.log(sql)
        const [result] = await readConn.query(sql, [data.email]);
        return result.length > 0 ? result[0] : false;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}

module.exports.logout = async (data) => {
    try {
        const sql = "UPDATE user_activity SET logout_datatime = CURRENT_TIMESTAMP() WHERE id = ?";
        const [result] = await writeConn.query(sql,
            [data.userLogId]);
        
        return true;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}

module.exports.add_user_audit_logs = async (data) => {
    try {
        const sql = "INSERT INTO user_activity (user_id,login_datatime)" +
            " values (?,CURRENT_TIMESTAMP())";
        const [result] = await writeConn.query(sql,
            [data.user_id]);
        console.log(result.insertId)
        return result.insertId;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}
module.exports.check = async (data) => {
    try {
        const sql = "SELECT id  from user_details where deleted=0 AND email = ?";
        const [result] = await  readConn.query(sql,[data.email]);
        util.createLog(result.length);
        return result.length > 0;
    } catch (e) {
        util.createLog(e);
        return false;
    }

}
module.exports.add = async (data) => {
    try {
        const sql = "INSERT INTO user_details (name,email,password)" +
            " values (?,?,?)";
        const [result] = await writeConn.query(sql,
            [data.name, data.email, data.password]);
        
        return true;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}
module.exports.addimage = async (data) => {
    try {
        const sql = "INSERT INTO imagefile (image_url)" +
            " values (?)";
        const [result] = await writeConn.query(sql,
            [data.image_url]);
        
        return true;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}
module.exports.getImage = async (data) => {
    try {
        const sql = "SELECT * FROM `imagefile`" 
        const [result] = await writeConn.query(sql,
            []);
        
        return result;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}

module.exports.updatePassword = async (data) => {
    try {
        const sql = "update user_details set password=? where email=?";
        const [result] = await writeConn.query(sql,
            [ data.password,data.email]);
        
        return true;
    } catch (e) {
        util.createLog(e);
        return false;
    }
}