const readConn = require('../../dbconnection').readPool
const writeConn = require('../../dbconnection').writePool
const util = require('../../utility/util');
const axios = require("axios");
const config = require('../../config');
let ejs = require("ejs");
let pdf = require("html-pdf");
let path = require("path");
let fs = require("fs");


var date_ob = new Date();
var day = ("0" + date_ob.getDate()).slice(-2);
var month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
var year = date_ob.getFullYear();

