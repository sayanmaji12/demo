const formidable        =   require('formidable');
const fs                =   require('fs');
const config            =   require('../../config')

const genFileName = (filename) =>{
    let splfile = filename.split(".");
    let ext = splfile.pop();
    return 'DEMO'+Date.now()+"."+ext;
}

module.exports.handelFormData = async (req, type) => {
    try {
        return new Promise((resolve, reject) => {
            const form = formidable({multiples: true, uploadDir: config.FILEPATH});
            let filename = '';
            let orgfilename = '';
            form.on('file', function(field, file) {
                //rename the incoming file to the file's name
                orgfilename = file.originalFilename;
                filename = genFileName(file.originalFilename);
                fs.rename(file.filepath, form.uploadDir + "/" + filename, (err) => {
                    console.log('file error >> ', err);
                });
            });
            form.parse(req, async (err, fields, files) => {
                const data = fields;
                console.log(">>>>>>>>>>>>>>>>>> ", filename);
                data['fileName'] = filename;
                data['orgfilename'] = orgfilename;
                resolve(data)
            });
        })
    } catch (e) {
        console.log(e)
        resolve({})
    }
}
