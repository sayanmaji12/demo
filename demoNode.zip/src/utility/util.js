
const bcrypt = require('bcrypt');
const config = require('../config');

//create salt and encrypt password with salt
let generateHash = async (data) => {
    let saltRound = process.env.SALTROUND || config.SALTROUND;
    const salt = bcrypt.genSaltSync(Number(saltRound));
    const hash = bcrypt.hashSync(data, salt);
    return hash;
}




//match user input password and saved password for signin
let comparePass = async (inputPass, savedPass) => {
    let compare = await bcrypt.compare(inputPass, savedPass);
    return compare;
}



//6 digit random numerical otp generation
let generateSixDigitOtp = async()=>{
    let otp = await Math.floor(1000 + Math.random() * 9000);
    return otp;
}




let createLog = (data) => {
    if (process.env.EXECUTION_MODE == "prod" || config.EXECUTION_MODE == "prod") {
        return true;
    } else {
        console.log(data)
        return true;
    }
}





let encryptResponse = async (data) => {
    // const token1 = await token.GetWebToken(data);
    // const response = await encryptPayload(token1);
    // return response;
    return data
}

const statusCode = {
    SUCCESS: 200,
    INTERNAL: 500,
    SOME_ERROR_OCCURRED: 500,
    PARAM_MISSING: 1001,
    EMAIL_MISSING: 1002,
    MOBILE_MISSING: 1003,
    AUTH_ERR: 401,
    EMAIL_EXISTS: 1004,
    PHONE_EXISTS: 1004,
    NAME_EXISTS: 1004,
    CUSTOM_ERROR: 1005,
    PAYMENT_NOT_DONE: 1006,
    TOKEN_WRONG :1007,
    MAX_ATTEMP :1008,
    NOT_EXIST :404,
}

const groupBy = (xs, key) => {
    return xs.reduce(function (rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
    }, {});
}


module.exports = {
    generateHash: generateHash,
    comparePass: comparePass,
    createLog: createLog,
    encryptResponse: encryptResponse,
    statusCode: statusCode,
    generateSixDigitOtp: generateSixDigitOtp,
    groupBy: groupBy
}
