const jwtToken = require('jsonwebtoken');
const config = require('../config');
var CryptoJS = require("crypto-js");

//create jwt token
let GetWebToken = async (data) => {
    data.reqtime = Date.now();
    return jwtToken.sign({data}, process.env.JWTSECRET || config.JWTSECRET, {expiresIn: process.env.JWTTIME})
};


let authenticateToken = async (req, res, next) => {
    
    if (!config.omitTokenAPiPath.includes(req.url)) {
        const authHeader = req.headers['authorization']
        const token = authHeader && authHeader.split(' ')[1]
        console.log(req.url)
        if (token == null) return res.json({success: false, status: 401, message: "Token missing", response: ''});
        jwtToken.verify(token, process.env.JWTSECRET, (err, user) => {
            console.log(err)

            if (err) return res.json({success: false, status: 403, message: "Invalid signature ", response: ''});
            console.log('true')
            //   return true;

            next()
        })
    } else {
        console.log(req.url)
        next();
    }
}




module.exports = {
    GetWebToken: GetWebToken,
    authenticateToken: authenticateToken,
}
