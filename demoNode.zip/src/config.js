var path = require('path');

const local = false;
//url of the server
const URL = local ? 'http://localhost:6065/' : "http://localhost:6065/";
const LOGIN_URL = "http://localhost:6065/";


//for mode of execution
const EXECUTION_MODE = "stag";

//get root directoty of the location where source code is uploaded
const BASEPATH = path.resolve(__dirname, '..');

//configure enviroment file so source code can be executed from any location
require('dotenv').config({path: BASEPATH + '/src/.env'});

const controllerPath = BASEPATH + '/src/app/';
//location where files will be stored
const FILEPATH = BASEPATH + '/public/uploadedFiles/';


//defining en variables if env variable is not accessable


//LOCAL
const MYSQL_HOST = 'localhost';
const MYSQL_USER = 'root' ;
const MYSQL_PASSWORD = 'password';
const MYSQL_DB = 'demo';

//token validity in seconds
const TOKEN_VALIDITY = 3000;

//JWT details
const JWTSECRET = "demo@1234";

const JWT_ALGO = 'HS256';
//server port where application will accept request
const PORT = 6065;

//mysql config for
const MYSQL_CONFIG = {
    connectionLimit: 25,
    host: process.env.MYSQL_HOST || MYSQL_HOST,
    user: process.env.MYSQL_USER || MYSQL_USER,
    password: process.env.MYSQL_PASSWORD || MYSQL_PASSWORD,
    database: process.env.MYSQL_DB || MYSQL_DB,
    multipleStatements: true
};

//Redis config 
// const REDIS_CONFIG = {
//     host: process.env.REDIS_HOST || REDIS_HOST,
//     password: process.env.REDIS_PASSWORD || REDIS_PASSWORD,
//     port: process.env.REDIS_PORT || REDIS_PORT
// };
// public routes that don't require authentication
const omitTokenAPiPath = [
    '/login',
    '/register',
    '/fileupload',
    '/forgetpass/password',
];

const omitDecryptReqAPiPath = [
    
];


//salt rounds for generate salt and match/create encrypted password
const SALTROUND = 10;



module.exports = {
    controllerPath: controllerPath,
    MYSQL_CONFIG: MYSQL_CONFIG,
    FILEPATH: FILEPATH,
    URL: URL,
    LOGIN_URL: LOGIN_URL,
    MODE: "dev",
    MYSQL_HOST: MYSQL_HOST,
    MYSQL_USER: MYSQL_USER,
    MYSQL_PASSWORD: MYSQL_PASSWORD,
    MYSQL_DB: MYSQL_DB,
    TOKEN_VALIDITY: TOKEN_VALIDITY,
    JWTSECRET: JWTSECRET,
    JWT_ALGO: JWT_ALGO,
    PORT: PORT,
    omitTokenAPiPath: omitTokenAPiPath,
    EXECUTION_MODE: EXECUTION_MODE,
    BASEPATH: BASEPATH,
    SALTROUND: SALTROUND,
    omitDecryptReqAPiPath: omitDecryptReqAPiPath,
    API_BASE_URL: URL
};
